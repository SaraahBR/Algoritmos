package SomaMult;

public class somamult {
	
	
	
	public static void main(String[] args){
	
		int soma = 0;
		int MAX = 1000;
		
		for(int i = 0; i < MAX; i++){
		if(i % 3 == 0 || i % 5 == 0){
			soma += i;
		}
	}
		System.out.println("A soma de todos os multiplos de 3 e 5 sao: " + soma);
		}

}
