package Palindrimo;

public class maiorpalind {

    public static void main(String[] args) {
        int palindromomaior = 0;
        
        for (int i = 100; i <= 999; i++) {
            for (int j = 100; j <= 999; j++) {
                int product = i * j;
                
                if (PalindromoDois(product) && product > palindromomaior) {
                	palindromomaior = product;
                }
            }
        }
        
        System.out.println("Maior palindromo do produto de dois numeros de três digitos: " + palindromomaior);
    }
    
    public static boolean PalindromoDois(int n) {
        
    	String StringNum = String.valueOf(n);
        int size = StringNum.length();
        
        for (int i = 0; i < size/2; i++) {
            
        	if (StringNum.charAt(i) != StringNum.charAt(size-1-i)) {
                return false;
            }
        }
        
        return true;
    }

}