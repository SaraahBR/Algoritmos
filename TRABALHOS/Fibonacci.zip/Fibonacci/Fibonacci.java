package Fibonacci;

public class Fibonacci {
	
    public static void main(String[] args) {   
    int x = 0, y = 1, z = 0, adicao = 0;
    while (z <= 4000000) {
       x = y;
       y = z;
       z = x + y;
       
       if (z % 2 == 0)  {
       
    	   adicao += z;   
       }
       System.out.println("O resultado do fibonacci é: " + (adicao));
      }
    }
}
    
    
        
        
    			