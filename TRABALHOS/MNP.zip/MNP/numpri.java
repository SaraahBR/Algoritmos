package MNP;

public class numpri {
    
	public static void main(String[] args) {
        
		long numero = 600851475143L;
        long MN = 1;

        for (long i = 2; i <= numero; i++) {
            while (numero % i == 0) {
                numero /= i;
                MN = i;
            }
        }

        System.out.println("O maior fator primo de 600851475143 e " + MN);
    }
}