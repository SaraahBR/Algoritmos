package mmc;

public class MenMulCom {

    public static void main(String[] args) {
        
    	int MinMulCom = MMC(1, 20);
        
    	System.out.println("O MMC de 1 a 20 e: " + MinMulCom);
    }
    
    public static int MMC(int start, int end) {
        int MinMulCom = 1;
        
        for (int i = start; i <= end; i++) {
        	MinMulCom = calcMMC(MinMulCom, i);
        }
        
        return MinMulCom;
    }
    
    public static int calcMMC(int x, int y) {
        
    	int MDC = calcMDC(x, y);
        return x * (y / MDC);
    }
    
    public static int calcMDC(int x, int y) {
        if (y == 0) {
            return x;
        }
        
        return calcMDC(y, x % y);
    }

}
